% Jungho Kim, Truss analysis

function [F,U,R] = TS_analysis(D)

w = size(D.Re);
S = zeros(3*w(2));
U = 1-D.Re;
f = find(U);
for i = 1:size(D.Con,2)
    H = D.Con(:,i);
    C = D.Coord(:,H(2))-D.Coord(:,H(1));
    Le = norm(C);
    T = C/Le;
    s = T*T';
    G = D.E(i)*D.A(i)/Le;
    Tj(:,i) = G*T;
    e = [3*H(1)-2:3*H(1),3*H(2)-2:3*H(2)];
    S(e,e) = S(e,e)+G*[s -s;-s s];
end
if rank( S(f,f) ) < length(f)
    U = nan;
    F = nan;
    R = nan;
else
    U(f) = S(f,f)\D.Load(f);
    F = sum(Tj.*(U(:,D.Con(2,:))-U(:,D.Con(1,:))));
    R = reshape(S*U(:),w);
    R(f) = 0;
end

end % function end

